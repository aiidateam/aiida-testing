#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt


export AIIDA_MOCK_LABEL=diff
export AIIDA_MOCK_DATA_DIR=/Users/broeder/aiida/github/fork-aiida-testing/aiida-testing/tests/export_cache/calc_data
export AIIDA_MOCK_EXECUTABLE_PATH=/usr/bin/diff
export AIIDA_MOCK_IGNORE_FILES=_aiidasubmit.sh:file*

'/Users/broeder/aiida/envs/env_aiida_1_1/bin/aiida-mock-code' 'file1.txt' 'file2.txt'  > 'patch.diff' 
