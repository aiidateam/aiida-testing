#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt


'/bin/diff' 'file1.txt' 'file2.txt'  > 'patch.diff' 
